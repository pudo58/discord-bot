package io.github.pudo58.utils;

/**
 * @author pudo58
 * @since 05-06-2025
 */
public class EnvUtils {
    public static String getEnv(String key) {
        return System.getenv(key);
    }
}
