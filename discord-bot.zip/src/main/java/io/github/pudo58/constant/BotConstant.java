package io.github.pudo58.constant;

public class BotConstant {
    // bot giới thiệu
    public static final String BOT_INTRODUCTION_KEY = "BOT_INTRODUCTION_KEY";
    public static final String BOT_NOXUS = "BOT_NOXUS";
}
