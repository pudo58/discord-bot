package io.github.pudo58.constant;

public class RankConstant {
    public static final String BRONZE = "Đồng";
}
